<?php
require('inc/ojsettings.php');

if(!isset($_POST['type']))
	die('Invalid argument.');
$nowtime = date("Y/m/d H:i:s");

else if($_POST['type'] == 'check'){
	$updxml = $updloc.'info.xml';
	$curl = curl_init($updxml);
	$timeout = 10;
	curl_setopt ($curl, CURLOPT_NOBODY, true);
	curl_setopt ($curl, CURLOPT_CONNECTTIMEOUT, $timeout); 
	$result = curl_exec($curl);
	$found = false;
	if ($result !== false) {
		$statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		if ($statusCode == 200) $found = true;
	}	
	curl_close($curl);
	if ($found == false) die('error');

	$xml = new DOMDocument(); 
	$xml->load($updxml); 
	foreach($xml->getElementsByTagName('latest') as $list)
	$latest = $list->nodeValue; 
	if($latest>$web_ver) echo $latest;
	else echo 'false';
}

else if($_POST['type'] == 'update'){
	if(!isset($_POST['newver']))
		die('Invalid argument.');
	foreach($xml->getElementsByTagName('last') as $list) 
	$last = $list->nodeValue; 
	if($last == $web_ver) //Get update zip file
		$updfile = $updloc.'delta_'.$_POST['newver'].'.zip';
	else
		$updfile = $updloc.'full_'.$_POST['newver'].'.zip';

	
	set_time_limit (24 * 60 * 60);         
if (!isset($_POST['submit'])) die();         
$destination_folder = './client/';   // 文件夹保存下载文件。必须以斜杠结尾         
$url = $_POST['url'];         
$newfname = $destination_folder . basename($url);         
$file = fopen ($url, "rb");         
if ($file) {         
$newf = fopen ($newfname, "wb");         
if ($newf)         
while(!feof($file)) {         
fwrite($newf, fread($file, 1024 * 8 ), 1024 * 8 );         
}         
}         
if ($file) {         
fclose($file);         
}         
if ($newf) {         
fclose($newf);         
}         
	
}
?>