<script type="text/x-mathjax-config">
MathJax.Hub.Config({
	extensions: ["tex2jax.js"],
	// jax: ["input/TeX", "output/HTML-CSS"],
	tex2jax: {
	  inlineMath: [ ['[inline]','[/inline]'] ],
	  displayMath: [ ["[tex]","[/tex]"] ]
	},
	"HTML-CSS": { availableFonts: ["TeX"], webFont: "TeX", imageFont: null }
});
</script>
<!--<script type="text/javascript"  src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>-->
<script async type="text/javascript" src="../assets/Mathjax/MathJax.js?config=TeX-AMS-MML_HTMLorMML"></script>
