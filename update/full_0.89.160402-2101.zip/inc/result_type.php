<?php
static $RESULT_TYPE=array(
    0 => 'Accepted',
    7 => 'Compile Error',
    2 => 'Time Out',
    3 => 'Memory Exceeded',
    4 => 'Wrong Answer',
    5 => 'Runtime Error',
    //6 => 'Wrong Answer',//'Output Limit Exceed',
    //1 => 'Wrong Answer',//'Presentation Error',
    //98 => 'Runtime Error',//'System Error',
    99 => 'Validator Error'
  );

static $RESULT_STYLE=array(
    0 => 'label-success',
    7 => '',
    2 => 'label-warning',
    3 => 'label-warning',
    4 => 'label-important',
    5 => 'label-info',
    //6 => 'label-important',//'Output Limit Exceed',
    //1 => 'label-important',//'Presentation Error',
    //98 => 'label-info',//'System Error',
    99 => 'label-inverse'
  );
?>