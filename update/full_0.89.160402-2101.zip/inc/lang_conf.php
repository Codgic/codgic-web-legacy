<?php
static $LANG_NAME=array(
    0 => 'G++',
    1 => 'GCC',
    2 => 'Pascal',
    3 => 'G++(0x)',
  );

static $LANG_EXT=array(
    0 => 'cpp',
    1 => 'c',
    2 => 'pas',
    3 => 'cpp',
  );
