<?php
define("MAIL_FLAG_REPLY",1);
define("MAIL_FLAG_STAR",2);